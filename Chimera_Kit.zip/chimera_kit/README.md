# Chimera Kit for Blender

Version 1.3.0. The top of the sidebar must say **Version 1.3.0 loaded**. An already running Blender session keeps its loaded Python code; replacing the ZIP on disk does not refresh that session. Reinstall the ZIP and restart Blender, or start a fresh session with **Launch Chimera Kit.cmd** to load this folder's current source.

Chimera Kit is a Blender-native creature rigging and procedural motion add-on inspired by the installed 3ds Max Biped/CAT workflow. It creates editable custom armatures, IK controls, preview mannequins, locomotion actions, NLA clips, skin bindings, recipes and interchange exports.

The requested REA repository is preserved at [`reference/rea`](reference/rea). The investigation used REA 6.7.0 against the installed 3ds Max CAT plug-in and its UI resources. The independent range decoder extracted 311 feature labels, including CATMotion, MaxStrideLength, ActualStrideLength, IKFKRatio, FootPrints and MotionWeight, and inventoried 21 shipped creature presets. The native-provider attempt records that deep decompilation is unavailable until a configured analysis engine is supplied. Evidence, artifact hashes, byte ranges and limitations are in [`research`](research/README.md). The Blender implementation contains original code and generated geometry.

## Install

For this PC, double-click **Launch Chimera Kit.cmd**. This opens the Dragon demo in Blender 5.1 and loads the add-on from this folder for that session. It does not change your saved preferences or existing add-ons.

To install permanently:

1. Open **Edit → Preferences → Add-ons → menu → Install from Disk** and select **Chimera_Kit.zip**.
2. Enable **Chimera Kit**.
3. In the 3D View press `N`, choose **Chimera Kit**, and start with **Build new creature**.

For a source checkout, Blender can load the package directly with:

```python
import sys
sys.path.insert(0, r"G:\DEV\Character_Studio")
import chimera_kit
chimera_kit.register()
```

`Character_Studio_Demo.blend` is a ready-to-open Dragon example. The test command below creates its own temporary scene and does not depend on the demo file.

## Workflow

**Live body.** After a creature is built, its body sliders stay live: size, body length and width, leg, arm and neck length, head size, and the leg-pair, spine, neck and tail link counts, plus the accessory and mannequin switches. Change one and the active creature is rebuilt in place about a fifth of a second after the control stops moving, keeping its name, position, cycle, layers, limb settings, saved poses, bound meshes and footsteps; the playing cycle is regenerated for the new proportions. Selecting another creature loads its values into the sliders. Choosing a different preset in the menu sets up a new creature and leaves the active one alone. Creatures that were fitted by hand or have appended structures are not rebuilt, because that would discard the hand edits. Proportion sliders now run up to 10, body length to 40 and neck length to 80 (type a value to go past the slider's soft limit), and link counts to 30–80.

The sidebar is split into five colour-tagged workflow tabs: **Build**, **Animate**, **Layers**, **Retarget** and **Export**. Only the panels of the chosen tab are shown.

**Cycles.** The Animate tab generates five kinds of cycle: **Walk** (or swim), **Idle** (planted feet, breathing), **Jump** (crouch, push off, flight, landing; height, crouch depth and travel distance), **Punch** and **Kick** (side or alternate, and strike height). Each is a separate action that live update keeps in step with the sliders. A **Run** motion style and a **Forward lean** slider cover faster gaits. With **All generated cycles** on, GLB and FBX export write every cycle generated for the creature as its own clip.

**Wings, jaw and antennae.** Their motion controls are in Animate › Motion tuning. Wings have five motions (Flap, Glide, Hover, Flutter, Folded), a beat size, beats per cycle and a fold amount; the fingers and membrane close like a fan as the wing folds, and birds walk with folded wings by default. A **Jaw** accessory adds a hinged lower jaw to any creature; it opens on a chosen share of cycles, by a chosen angle, a chosen number of times per cycle, and is always shut where the cycle loops. Antennae start on the surface of the head whatever its size and have their own length and link count; their sway is shared between the links.

**Footsteps.** Create footsteps for a travelling walk, then edit the markers: the feet land on them and the body now follows the path they imply, turning, climbing or descending with them. **Select from active step onward** picks the rest of the walk and pivots on the active step, so R Z turns the walk there; Blender's proportional editing (O) gives a soft falloff for slopes and curves.

**Creature builder** provides 31 presets (Giraffe joins Four legs, Brontosaurus joins Reptiles & dinosaurs), grouped in the menu as Humanoids, Mechs, Four legs, Reptiles & dinosaurs, Birds, Swimmers and Many legs. New in this round: Bird, Eagle, Ostrich and Penguin; Fish, Shark, Dolphin and Whale, which have no legs and swim (fish beat the tail side to side, cetaceans up and down); and three original mech body types, Trooper (armoured humanoid), Flyer (winged humanoid) and Walker pod (cockpit on reverse-jointed legs). **Biped** is the default: a box figure with a centre-of-mass control, pelvis, spine links, clavicles, arms, up to five three-link fingers, legs and a separate toe, coloured blue on the left and green on the right (see `preview_biped.png`). The Mannequin switch draws any preset as flat-shaded boxes or as the earlier rounded shapes. The other presets are Human, Ape, Mech, Horse, Gnou, Panther, Lizard, Alien, Allosaur, Dragon, Angel, Spider, Crab, Centipede and Centaur. Allosaur and T-Rex are level-bodied theropods with a balancing tail and digitigrade legs: the Allosaur is lighter with longer three-clawed arms, the T-Rex has a massive head and tiny two-clawed arms. Centaur is a four-legged body with an upright torso and arms. Lizard and Gecko sprawl with their legs out to the sides and walk on diagonal pairs with a bending spine; the Lizard is long with a whip tail, the Gecko short with a big head, fat tail and wide feet. Alien is a slender biped with antennae. Four-legged presets stand on raised ankles: front legs fold at a backward elbow, hind legs at a forward stifle and a backward hock. **Accessories** adds a tail, wings, antennae or a ponytail to any preset; antennae and ponytail lag behind the body (Follow-through slider), and Foot roll tips each foot toe-down as it leaves the ground. These are independent Blender designs, with articulated wings, crab claws, gnou horns, alien antennae and different body proportions. They do not reproduce all 21 Autodesk presets. Change body dimensions and link counts before building.

**Append custom structures** adds a hub, spine chain with a hub, tail, leg pair with IK, or FK arm pair to the active rig. Choose a parent bone, append, then use Fit mode. Appending returns the creature to rest and preserves its previous actions as data. JSON recipes save base structure and global motion settings; save the Blender file to preserve appended bones and edited rest positions.

**Pose & fit** gives each limb an IK foot target and pole control. Start Fit mode to move edit bones against an imported mesh, finish it to recalibrate the IK planes, then capture named poses, mirror them or key the current pose.

**Skin your mesh** binds selected artist meshes with deterministic closest-segment distance weights or Blender automatic weights. Generated preview meshes are marked and excluded from binding. Hide the mannequin whenever you want to inspect your own mesh.

**Procedural locomotion** creates a native Blender action with stance, swing, stride, lift, planting, gait and cycle controls. Walk, trot/tripod, pace and bound timings are supported. Enable Travel forward for root translation, or supply one un-beveled open curve for path following. Beyond an open curve's end, travel continues along its final tangent.

The trunk moves by default: the hips turn toward the leading foot, the chest counter-rotates, and the spine bends and flexes along its links. Spine sliders set the angle of the whole trunk, shared between links. **Motion tuning & exaggeration** exposes body height, bounce and frequency, sway, roll, pitch, twist, phase, spine bend/twist, head bob, arm swing, wing flap, tail swing/lift/frequency/stiffness/phase. Neutral, Sneak, Heavy and Cartoon styles set these sliders. With **Live update** on (the default), generate a walk once, press **Play**, and every control in panels 02 and 03, the per-limb phase and lift values, footprint markers and the path curve reshape the walk as it plays. **On release** (the default) waits until a control stops moving; switch it off to update on every step of a drag. Live update rewrites the active walk in place and keeps the channels it was generated with; **New walk** starts a fresh action and preserves the previous one. Turn Live update off to change several controls before applying them.

**Per-limb timing & footprints** exposes individual foot phase, lift multipliers and IK weight. Old rigs have an Enable controls button. Generate traveling footprints, then move or rotate the markers in Object mode; the walk follows. Markers represent ankle targets; their height starts at each foot's rest ankle height. Changing stride, gait timing, rig transform or path requires recreating markers or disabling Use edited footprints. Plant feet locks stance targets in armature/world space; excessive motion can still move feet beyond the IK chain's reach.

**Animation layer manager** provides NLA weights, Replace/Add/Combine blending, mute, solo, timing and weight fades in the sidebar. Generate Full creature for a base layer; generate Tail only, Body + spine, Head/arms/wings, or Root + feet for an overlay. Add the active action as a layer, then Enable all. Generation isolates its action by muting stored tracks. Play enabled layers detaches the active action and uses the current mute/solo states. After changing a strip's time range, click Apply range / fade changes. Edit / read activates its source action and restores stored global motion sliders.

**Retarget, Mixamo & CloudRig** copies motion from one armature to another. Pick **Motion from** and **Apply to**, press **Auto-map bones**, check the table, then **Retarget motion**.

- *Creature → CloudRig.* Generate a walk, footsteps or a layer stack on a creature, choose it as the source and the generated CloudRig armature as the target. The motion is sampled as it plays, so enabled layers and edited footprints are included. FK controls (`FK-…`), IK feet (`IK-…Foot`), knee poles and the torso master are keyed in one new action. Legs default to **FK + IK**, so the walk plays whichever mode the legs are in. Arms are keyed on FK controls only: switch the arms to FK in the rig UI.
- *Mixamo → creature or CloudRig.* **Import Mixamo FBX** loads the file, selects it as the source and maps it to the active creature. Feet land on the creature's IK foot controls and knee poles, so they stay editable.
- *Any skeleton → any skeleton.* Bones are recognised by name (Mixamo, Unreal-style, Rigify-style and CloudRig-style prefixes) and by their place in the body. Unrecognised bones are left empty in the table; fill them in by hand and save the map as JSON for reuse.

Rest poses do not have to match: a T-pose source drives an A-pose target. Travel and foot height are scaled by leg length and measured from the ground, so planted feet stay planted on a taller or shorter character. Both characters should face the same way before retargeting. **In place** removes horizontal travel.

**Library & export** saves and loads JSON creature recipes, validates the armature and IK inventory, writes a JSON asset manifest, exports a selected rigged collection to GLB/FBX, and can bake an independent skeleton for downstream DCC interchange.

## Verification

From this folder:

```powershell
python -m compileall -q chimera_kit tests
& "C:\Program Files\Blender Foundation\Blender 5.1\blender.exe" --background --factory-startup --python-exit-code 1 --python tests/smoke_blender.py
```

The smoke test builds every preset, validates IK rest pose error, checks the loop seam and finite poses, verifies planted stance controls on a transformed 12-legged rig, exercises NLA, and exports animated GLB and FBX. `tests/workflows_blender.py` also verifies rig fitting, normalized skin weights, pose capture/restore, mirror, pose keying, recipes, curve following, skeleton baking and manifests. `tests/retarget_blender.py` builds a Mixamo-named skeleton and a CloudRig-style control rig from scratch, round-trips the animation through FBX, and checks limb directions, scaled travel, IK foot placement and planted feet for Mixamo → Biped, Mixamo → control rig, creature walk → control rig and control rig → skeleton. `tests/live_blender.py` checks that sliders, cycle length, per-limb values and moved footprints rewrite the active action without creating a new one or moving the playhead. `tests/cycles_blender.py` checks idle, jump, punch, kick, the run style, multi-clip GLB export, swimming, and footsteps that turn the walk 60° and climb. `tests/livebody_blender.py` checks live rebuilding, long necks and extreme proportions. `tests/parts_blender.py` checks antenna placement at two head sizes in both mannequin styles, antenna length and links, jaw timing, the five wing motions, the Brontosaurus and a 40× body with an 80× neck. `tests/package_blender.py` enables the release zip in an isolated test directory and reopens the saved demo. The 1.1.0 checks passed in Blender 5.1 on this PC. The 1.2.0 suites were run with the Blender 5.1.2 Python module on another machine, not yet in this PC's Blender, and the CloudRig path was tested against a stand-in rig with CloudRig-style names, not a rig generated by the CloudRig add-on. Source targets Blender 4.2+, but older versions were not run.

The automated Windows computer-use tool denied access to Blender, so a live visual sidebar check could not be completed. Panel draw paths were checked through Blender Python. The focused feature suite covers footprint editing, per-limb controls, styles, NLA layers and appended modules; the layer evaluation suite checks actual blended poses and weight fades.

## Scope

The feature-by-feature comparison and remaining gaps are recorded in [research/FEATURE_AUDIT.md](research/FEATURE_AUDIT.md).

This is an independent Blender tool inspired by CAT's exposed features. The preview mannequin is a segmented blockout; use your own production mesh and refine weights. Stance controls lock on a turning path, but very sharp turns, unreachable targets, extreme exaggeration or blended foot layers can produce sliding or overstretch. No terrain collision solver, Autodesk solver parity, proprietary `.bip`/CAT `.rig` import or crowd system is implemented. The retargeter does not key IK hand controls, does not switch a target rig's IK/FK properties, and does not correct twist differences between rest poses beyond aligning each bone's direction.

The add-on source is GPL-3.0-or-later; see `LICENSE`. REA retains its own license under `reference/rea` and is not bundled into the Blender zip.
